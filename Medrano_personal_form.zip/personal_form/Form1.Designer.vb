﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btn_x = New System.Windows.Forms.Button()
        Me.btn_j = New System.Windows.Forms.Button()
        Me.label_name = New System.Windows.Forms.Label()
        Me.label_age = New System.Windows.Forms.Label()
        Me.label_address = New System.Windows.Forms.Label()
        Me.tb_name = New System.Windows.Forms.TextBox()
        Me.tb_a = New System.Windows.Forms.TextBox()
        Me.tb_d = New System.Windows.Forms.TextBox()
        Me.btn_txt = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn_x
        '
        Me.btn_x.BackColor = System.Drawing.Color.LightSalmon
        Me.btn_x.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_x.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_x.ForeColor = System.Drawing.Color.Black
        Me.btn_x.Location = New System.Drawing.Point(189, 219)
        Me.btn_x.Name = "btn_x"
        Me.btn_x.Size = New System.Drawing.Size(75, 36)
        Me.btn_x.TabIndex = 1
        Me.btn_x.Text = "XML"
        Me.btn_x.UseVisualStyleBackColor = False
        '
        'btn_j
        '
        Me.btn_j.BackColor = System.Drawing.Color.LightSalmon
        Me.btn_j.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_j.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_j.ForeColor = System.Drawing.Color.Black
        Me.btn_j.Location = New System.Drawing.Point(323, 219)
        Me.btn_j.Name = "btn_j"
        Me.btn_j.Size = New System.Drawing.Size(75, 36)
        Me.btn_j.TabIndex = 2
        Me.btn_j.Text = "JSON"
        Me.btn_j.UseVisualStyleBackColor = False
        '
        'label_name
        '
        Me.label_name.AutoSize = True
        Me.label_name.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_name.Location = New System.Drawing.Point(49, 37)
        Me.label_name.Name = "label_name"
        Me.label_name.Size = New System.Drawing.Size(71, 30)
        Me.label_name.TabIndex = 3
        Me.label_name.Text = "Name"
        '
        'label_age
        '
        Me.label_age.AutoSize = True
        Me.label_age.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_age.Location = New System.Drawing.Point(50, 93)
        Me.label_age.Name = "label_age"
        Me.label_age.Size = New System.Drawing.Size(52, 30)
        Me.label_age.TabIndex = 4
        Me.label_age.Text = "Age"
        Me.ToolTip1.SetToolTip(Me.label_age, "Please enter a valid input (number).")
        '
        'label_address
        '
        Me.label_address.AutoSize = True
        Me.label_address.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label_address.Location = New System.Drawing.Point(50, 144)
        Me.label_address.Name = "label_address"
        Me.label_address.Size = New System.Drawing.Size(91, 30)
        Me.label_address.TabIndex = 5
        Me.label_address.Text = "Address"
        '
        'tb_name
        '
        Me.tb_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_name.Location = New System.Drawing.Point(167, 42)
        Me.tb_name.Name = "tb_name"
        Me.tb_name.Size = New System.Drawing.Size(198, 26)
        Me.tb_name.TabIndex = 6
        '
        'tb_a
        '
        Me.tb_a.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_a.ForeColor = System.Drawing.SystemColors.InfoText
        Me.tb_a.Location = New System.Drawing.Point(167, 93)
        Me.tb_a.Name = "tb_a"
        Me.tb_a.Size = New System.Drawing.Size(198, 26)
        Me.tb_a.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.tb_a, "Please enter a valid input (number)." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10))
        '
        'tb_d
        '
        Me.tb_d.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tb_d.Location = New System.Drawing.Point(167, 144)
        Me.tb_d.Name = "tb_d"
        Me.tb_d.Size = New System.Drawing.Size(198, 26)
        Me.tb_d.TabIndex = 8
        '
        'btn_txt
        '
        Me.btn_txt.BackColor = System.Drawing.Color.LightSalmon
        Me.btn_txt.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btn_txt.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_txt.ForeColor = System.Drawing.Color.Black
        Me.btn_txt.Location = New System.Drawing.Point(54, 219)
        Me.btn_txt.Name = "btn_txt"
        Me.btn_txt.Size = New System.Drawing.Size(75, 36)
        Me.btn_txt.TabIndex = 9
        Me.btn_txt.Text = "TXT"
        Me.btn_txt.UseVisualStyleBackColor = False
        '
        'ToolTip1
        '
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(83, 71)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(353, 70)
        Me.Label1.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.Label1, "Please enter a valid input (number).")
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MistyRose
        Me.ClientSize = New System.Drawing.Size(448, 292)
        Me.Controls.Add(Me.btn_txt)
        Me.Controls.Add(Me.tb_d)
        Me.Controls.Add(Me.tb_a)
        Me.Controls.Add(Me.tb_name)
        Me.Controls.Add(Me.label_address)
        Me.Controls.Add(Me.label_age)
        Me.Controls.Add(Me.label_name)
        Me.Controls.Add(Me.btn_j)
        Me.Controls.Add(Me.btn_x)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Personal Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_x As Button
    Friend WithEvents btn_j As Button
    Friend WithEvents label_name As Label
    Friend WithEvents label_age As Label
    Friend WithEvents label_address As Label
    Friend WithEvents tb_name As TextBox
    Friend WithEvents tb_a As TextBox
    Friend WithEvents tb_d As TextBox
    Friend WithEvents btn_txt As Button
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents Label1 As Label
End Class
